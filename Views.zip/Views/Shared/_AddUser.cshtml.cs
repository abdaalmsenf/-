using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CompalintsSystem.Views.Shared
{
    public class _AddUserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
