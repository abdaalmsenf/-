﻿namespace CompalintsSystem.Core.Interfaces
{
    public interface IEntityBase
    {
        public int Id { get; set; }
    }
}
