﻿namespace ComplantSystem.Service.Helpers
{
    public class RolesList
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
