﻿namespace CompalintsSystem.Core
{
    public class UserRoles
    {
        public const string AdminGeneralFederation = "AdminGeneralFederation";
        public const string AdminColleges = "AdminColleges";
        public const string AdminDepartments = "AdminDepartments";
        public const string AdminSubDepartments = "AdminSubDepartments";
        //public const string AdminVillages = "AdminVillages";
        public const string Beneficiarie = "Beneficiarie";


    }
}
