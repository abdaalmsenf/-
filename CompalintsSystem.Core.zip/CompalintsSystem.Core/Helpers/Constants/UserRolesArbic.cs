﻿namespace CompalintsSystem.Core.Helpers.Constants
{
    public class UserRolesArbic
    {
        public const string AdminGeneralFederation = "مدير عام";
        public const string AdminColleges = "عميد كلية";
        public const string AdminDepartments = "رئيس قسم";
        public const string AdminSubDepartments = "ادارة شئون الطلاب";
        //public const string AdminVillages = "AdminVillages";
        public const string Beneficiarie = "مستخدم";
    }
}
