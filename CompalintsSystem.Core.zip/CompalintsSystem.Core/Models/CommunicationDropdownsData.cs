﻿namespace CompalintsSystem.Core.Models
{
    public class CommunicationDropdownsData
    {
        //public int CollegesId { get; set; }
        //public int DirectoryId { get; set; }
        //public int SubDirectoryId { get; set; }
        //public string rolesString { get; set; }

    }
}
