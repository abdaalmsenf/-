﻿namespace CompalintsSystem.Core.ViewModels
{
    public class SelectLocationDropdownsVM
    {
        //public SelectLocationDropdownsVM()
        //{
        //    Collegess = new List<Colleges>();
        //    Departmentss = new List<Departments>();
        //    SubDepartmentss = new List<SubDepartments>();
        //    Villages = new List<Village>();
        //}

        //public List<Colleges> Collegess { get; set; }
        //public List<Departments> Departmentss { get; set; }
        //public List<SubDepartments> SubDepartmentss { get; set; }
        //public List<Village> Villages { get; set; }
    }
}
