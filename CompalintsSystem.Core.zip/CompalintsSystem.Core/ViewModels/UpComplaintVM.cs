﻿namespace CompalintsSystem.Core.ViewModels
{
    public class UpComplaintVM
    {
        public int UploadsComplainteId { get; set; }
        public int Id { get; set; }

        public string Cause { get; set; }
    }
}
