﻿namespace CompalintsSystem.Core.ViewModels
{
    public class ComplaintsUpVM
    {
        public string UploadsComplainteId { get; set; }
        public string Cause { get; set; }
    }
}
