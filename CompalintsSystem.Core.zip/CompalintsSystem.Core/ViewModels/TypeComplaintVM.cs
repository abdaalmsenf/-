﻿
using CompalintsSystem.Core.Models;

namespace CompalintsSystem.Core.ViewModels
{
    public class TypeComplaintVM
    {
        public TypeCompalintVM ViewTypeCompalintVM { get; set; }
        public TypeComplaint AddTypeComplaintVM { get; set; }
    }
}
