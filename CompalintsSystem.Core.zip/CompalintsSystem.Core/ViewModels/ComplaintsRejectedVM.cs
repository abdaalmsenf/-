﻿namespace CompalintsSystem.Core.ViewModels
{
    public class ComplaintsRejectedVM
    {

        public int UploadsComplainteId { get; set; }
        public string reume { get; set; }
    }
}
