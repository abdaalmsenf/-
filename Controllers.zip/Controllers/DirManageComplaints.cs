﻿using CompalintsSystem.Core.Interfaces;
using CompalintsSystem.Core.Models;
using CompalintsSystem.Core.Statistics;
using CompalintsSystem.Core.ViewModels;
using CompalintsSystem.EF.DataBase;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Rotativa.AspNetCore;
using Rotativa.AspNetCore.Options;
namespace CompalintsSystem.Application.Controllers
{
    [Authorize(Roles = "AdminDepartments")]
    public class DirManageComplaintsController : Controller
    {
        private readonly IUserService _userService;
        private readonly ICompalintRepository _compReop;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;
        private readonly ICategoryService _service;
        private readonly AppCompalintsContextDB _context;

        public DirManageComplaintsController(
            ICategoryService service,
            ICompalintRepository compReop,
            IUserService userService,
            UserManager<ApplicationUser> userManager,
            IWebHostEnvironment env,
            AppCompalintsContextDB context)
        {

            _compReop = compReop;
            _userService = userService;
            _userManager = userManager;
            _service = service;
            _context = context;
            _env = env;

        }

        private string UserId
        {
            get
            {
                return User.FindFirstValue(ClaimTypes.NameIdentifier);
            }
        }

        public async Task<IActionResult> Index(int? page)
        {
            var currentUser = await _userManager.GetUserAsync(User);

            var allCompalintsVewi = await _compReop.GetAllAsync(
                                    g => g.Colleges,
                                    d => d.Departments,
                                    b => b.SubDepartments,
                                    s => s.StagesComplaint
                                );

            var compBy = allCompalintsVewi
                .Where(g =>
                    g.SubDepartmentsId == currentUser.SubDepartmentsId &&
                    g.StagesComplaintId == 2 &&
                    g.StatusCompalintId == 5
                );
            int totalCompalints = compBy.Count();
            //ViewBag.TotalCompalints = Convert.ToInt32(page != 0 && totalCompalints);
            ViewBag.TotalNewCompalints = totalCompalints;

            return View(compBy.ToList());
        }

        public async Task<IActionResult> Report()
        {

            var currentUser = await _userManager.GetUserAsync(User);



            //-------------أحصائيات بالمستخدمين التابعين لنفس قسم الموضف--------------------//


            List<UsersInStatistic> usersIn = new List<UsersInStatistic>();
            usersIn = ViewBag.totalUserSubDir;

            List<ApplicationUser> applicationUsers = await _context.Users
                .Where(s => s.DepartmentsId == currentUser.DepartmentsId && s.RoleId == 4 || s.RoleId == 5)
                .Include(su => su.SubDepartments).ToListAsync();

            //Totalcountuser
            int TotalUsers = applicationUsers.Count();

            ViewBag.Users = TotalUsers;

            //total Govermentuser
            ViewBag.totalUserSubDir = applicationUsers.GroupBy(j => j.SubDepartmentsId).Select(g => new UsersInStatistic
            {
                Name = g.First().SubDepartments.Name,
                totalUsers = g.Count().ToString(),
                Users = (g.Count() * 100) / TotalUsers


            }).ToList();



            //------------- نـــــهاية أحصائيات بالمستخدمين التابعين لنفس قسم الموضف--------------------//


            //-------------أحصائيات انواع الشكاوى المقدمة لنفس قسم الموضف--------------------//



            List<UploadsComplainte> compalints = await _context.UploadsComplaintes
                .Where(s => s.DepartmentsId == currentUser.DepartmentsId)
                .Include(su => su.TypeComplaint).ToListAsync();
            List<TypeCompalintStatistic> typeCompalints = new List<TypeCompalintStatistic>();
            typeCompalints = ViewBag.GrapComplanrType;

            int totalcomplant = compalints.Count();
            ViewBag.Totalcomplant = totalcomplant;

            ViewBag.GrapComplanrType = compalints.GroupBy(x => x.TypeComplaintId).Select(g => new TypeCompalintStatistic
            {
                Name = g.First().TypeComplaint.Type,
                TotalCount = g.Count().ToString(),
                TypeComp = (g.Count() * 100) / totalcomplant
            }).ToList();




            //------------- نهاية أحصائيات انواع الشكاوى المقدمة لنفس قسم الموضف--------------------//


            //-------------أحصائيات حالات الشكاوى المقدمة لنفس قسم الموضف--------------------//


            List<UploadsComplainte> stutuscompalints = await _context.UploadsComplaintes
                .Where(s => s.DepartmentsId == currentUser.DepartmentsId)
                .Include(su => su.StatusCompalint).ToListAsync();
            List<StutusCompalintStatistic> stutusCompalints = new List<StutusCompalintStatistic>();
            stutusCompalints = ViewBag.GrapComplanrStutus;

            int totalStutuscomplant = stutuscompalints.Count();
            ViewBag.TotalStutusComplant = totalStutuscomplant;

            ViewBag.GrapComplanrStutus = stutuscompalints.GroupBy(s => s.StatusCompalintId).Select(g => new StutusCompalintStatistic
            {
                Name = g.First().StatusCompalint.Name,
                TotalCountStutus = g.Count().ToString(),
                stutus = (g.Count() * 100) / totalStutuscomplant
            }).ToList();


            //------------- نهاية أحصائيات حالات الشكاوى المقدمة لنفس قسم الموضف--------------------//
            return View();
        }
        public async Task<IActionResult> AllUpComplaints()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var userId = currentUser.Id;

            var AllUpComplaints = await _compReop.GetAllAsync(
                g => g.Colleges,
                d => d.Departments,
                s => s.SubDepartments,
                n => n.StatusCompalint,
                st => st.StagesComplaint,
                up => up.ComplaintsUp);

            if (AllUpComplaints != null)
            {
                var Getrejected = AllUpComplaints.Where(
                    g => g.ComplaintsUp != null
                    && g.ComplaintsUp != null && g.ComplaintsUp.Any(rh => rh.UserId == userId)
                      && g.Departments != null && g.Departments.Id == currentUser.DepartmentsId
                    //&& g.StatusCompalint != null && g.StatusCompalint.Id == 5
                    //&& g.StagesComplaint != null && g.StagesComplaint.Id == 3
                    );


                int totalCompalints = Getrejected.Count();
                ViewBag.TotalCompalintsUp = totalCompalints;

                return View(Getrejected);
            }
            var emptyList = Enumerable.Empty<UploadsComplainte>(); // إنشاء قائمة فارغة من الشكاوى
            return View(emptyList); // إرجاع قائمة فارغة في حالة عدم وجود شكاوى مرفوضة
        }

        public async Task<IActionResult> ViewCompalintUpDetails(int id)
        {

            var ComplantList = await _compReop.FindAsync(id);
            AddSolutionVM addsoiationView = new AddSolutionVM()
            {
                UploadsComplainteId = id,

            };
            ComplaintsRejectedVM rejectView = new ComplaintsRejectedVM()
            {
                UploadsComplainteId = id,

            };
            UpComplaintVM upComplaint = new UpComplaintVM()
            {
                UploadsComplainteId = id,
            };
            ProvideSolutionsVM VM = new ProvideSolutionsVM
            {
                compalint = ComplantList,
                Compalints_SolutionList = await _context.Compalints_Solutions.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                ComplaintsRejectedList = await _context.ComplaintsRejecteds.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                RejectedComplaintVM = rejectView,
                UpComplaintCauseList = await _context.UpComplaintCauses.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                AddSolution = addsoiationView
            };
            return View(VM);
        }
        public async Task<IActionResult> AllRejectedComplaints()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var userId = currentUser.Id;

            var AllRejectedComplaints = await _compReop.GetAllAsync(
                g => g.Colleges,
                d => d.Departments,
                s => s.SubDepartments,
                n => n.StatusCompalint,
                st => st.StagesComplaint,
                rc => rc.ComplaintsRejecteds);
            if (AllRejectedComplaints != null)
            {
                var Getrejected = AllRejectedComplaints.Where(
                    g => g.ComplaintsRejecteds != null
                    && g.ComplaintsRejecteds != null && g.ComplaintsRejecteds.Any(rh => rh.UserId == userId)
                      && g.Departments != null && g.Departments.Id == currentUser.DepartmentsId
                    //&& g.StatusCompalint != null && g.StatusCompalint.Id == 4
                    //&& g.StagesComplaint != null && g.StagesComplaint.Id == 3
                    );


                int totalCompalintsRejected = Getrejected.Count();
                ViewBag.TotalCompalintsRejected = totalCompalintsRejected;

                return View(Getrejected);
            }
            var emptyList = Enumerable.Empty<UploadsComplainte>(); // إنشاء قائمة فارغة من الشكاوى
            return View(emptyList); // إرجاع قائمة فارغة في حالة عدم وجود شكاوى مرفوضة

        }
        //public async Task<IActionResult> AllRejectedComplaints()
        //{
        //    var currentUser = await _userManager.GetUserAsync(User);

        //    var AllRejectedComplaints = await _compReop.GetAllAsync(
        //        g => g.Colleges,
        //        d => d.Departments,
        //        s => s.SubDepartments,
        //        n => n.StatusCompalint,
        //        st => st.StagesComplaint);
        //    if (AllRejectedComplaints != null)
        //    {
        //        var Getrejected = AllRejectedComplaints.Where(g => g.Colleges.Id == currentUser.CollegesId
        //    && g.StatusCompalint.Id == 2 && g.StagesComplaint.Id == 4);
        //        var compalintDropdownsData = await _service.GetNewCompalintsDropdownsValues();

        //        ViewBag.StatusCompalints = new SelectList(compalintDropdownsData.StatusCompalints, "Id", "Name");
        //        ViewBag.TypeComplaints = new SelectList(compalintDropdownsData.TypeComplaints, "Id", "Type");

        //        ViewBag.status = ViewBag.StatusCompalints;
        //        int totalCompalints = Getrejected.Count();
        //        //ViewBag.TotalCompalints = Convert.ToInt32(page == 0 ? "false" : totalCompalints);
        //        ViewBag.totalCompalints = totalCompalints;

        //        return View(Getrejected);

        //    }

        //    var emptyList = Enumerable.Empty<UploadsComplainte>(); // إنشاء قائمة فارغة من الشكاوى
        //    return View(emptyList); // إرجاع قائمة فارغة في حالة عدم وجود شكاوى مرفوضة

        //}

        public async Task<IActionResult> ViewCompalintRejectedDetails(int id)
        {
            var ComplantList = await _compReop.FindAsync(id);
            AddSolutionVM addsoiationView = new AddSolutionVM()
            {
                UploadsComplainteId = id,

            };
            ComplaintsRejectedVM rejectView = new ComplaintsRejectedVM()
            {
                UploadsComplainteId = id,

            };
            ProvideSolutionsVM VM = new ProvideSolutionsVM
            {
                compalint = ComplantList,
                Compalints_SolutionList = await _context.Compalints_Solutions.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                ComplaintsRejectedList = await _context.ComplaintsRejecteds.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                RejectedComplaintVM = rejectView,
                AddSolution = addsoiationView
            };
            return View(VM);
        }


        public async Task<IActionResult> SolutionComplaints()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var userId = currentUser.Id;

            var AllSolutionComplaints = await _compReop.GetAllAsync(
                g => g.Colleges,
                d => d.Departments,
                s => s.SubDepartments,
                n => n.StatusCompalint,
                st => st.StagesComplaint,
                sc => sc.Compalints_Solutions);

            if (AllSolutionComplaints != null)
            {
                var Getrejected = AllSolutionComplaints.Where(
                    g => g.Compalints_Solutions != null && g.Compalints_Solutions.Any(rh => rh.UserId == userId)
                         && g.Departments != null && g.Departments.Id == currentUser.DepartmentsId
                    //&& g.SubDepartments != null && g.SubDepartments.Id == currentUser.SubDepartmentsId
                    //&& g.StatusCompalint != null && g.StatusCompalint.Id == 2
                    );

                int totalCompalintsSolution = Getrejected.Count();
                ViewBag.TotalCompalintsSolution = totalCompalintsSolution;

                return View(Getrejected);
            }
            var emptyList = Enumerable.Empty<UploadsComplainte>(); // إنشاء قائمة فارغة من الشكاوى
            return View(emptyList); // إرجاع قائمة فارغة في حالة عدم وجود شكاوى مرفوضة
        }

        public async Task<IActionResult> ViewUsers()
        {
            var currentUser = await _userManager.GetUserAsync(User);

            //var result = await _userService.GetAllAsync(currentIdUser, gov, dir, sub);
            var result = await _context.Users.Where(d => d.UserId == currentUser.IdentityNumber && d.EmailConfirmed != false && d.RoleId != 5)
                .OrderByDescending(d => d.CreatedDate)
                .Include(g => g.Colleges)
                .Include(g => g.Departments)
                .Include(g => g.SubDepartments)
                .ToListAsync();

            int totalUsers = result.Count();

            ViewBag.totalUsers = totalUsers;
            //return View(await PaginatedList<ApplicationUser>.CreateAsync(result.AsNoTracking(), pageNumber ?? 1, pageSize));
            return View(result.ToList());

        }

        public async Task<IActionResult> BeneficiariesAccount()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var result = await _context.Users.Where(r => r.RoleId == 5 && r.DepartmentsId == currentUser.DepartmentsId)
                .Include(g => g.Colleges)
                .Include(g => g.Departments)
                .Include(g => g.SubDepartments)
                .ToListAsync();

            int totalUsers = result.Count();
            ViewBag.totalUsers = totalUsers;
            return View(result.ToList());
        }

        public async Task<IActionResult> AccountRestriction()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var currentIdUser = currentUser.IdentityNumber;
            var result = await _context.Users.Where(u => u.EmailConfirmed == false && u.UserId == currentUser.IdentityNumber)
                .OrderByDescending(d => d.CreatedDate)
                .Include(s => s.Colleges)
                .Include(g => g.Departments)
                .Include(d => d.SubDepartments)
                .ToListAsync();

            return View(result.ToList());

        }

        // GET: Users/Create
        public async Task<IActionResult> Create()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var currentName = currentUser.FullName;
            var model = new AddUserViewModel()
            {
                CollegessList = await _context.Collegess.ToListAsync()
            };
            ViewBag.ViewGover = model.CollegessList.ToArray();
            return View(model);
        }

        [HttpPost]

        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AddUserViewModel model)
        {
            model.CollegessList = await _context.Collegess.ToListAsync();
            var currentUser = await _userManager.GetUserAsync(User);
            var currentName = currentUser.FullName;
            var currentId = currentUser.IdentityNumber;

            if (ModelState.IsValid)
            {
                var userIdentity = await _userManager.FindByEmailAsync(model.IdentityNumber);
                if (userIdentity != null)
                {
                    ModelState.AddModelError("Email", "email aoset");
                    model.CollegessList = await _context.Collegess.ToListAsync();
                    ViewBag.ViewGover = model.CollegessList.ToArray();
                    return View(model);
                }
                if (_userService.returntype == 1)
                {
                    TempData["Error"] = _userService.Error;
                    return View(model);
                }
                else if (_userService.returntype == 2)
                {
                    TempData["Error"] = _userService.Error;
                    return View(model);
                }

                await _userService.AddUserAsync(model, currentName, currentId);

                return RedirectToAction("ViewUsers");
            }
            return View(model);
        }
        // GET: Users/Details/5
        public async Task<IActionResult> Details(string id)
        {
            var users = await _userService.GetAllAsync();
            ViewBag.UserCount = users.Count();

            var user = await _userService.GetByIdAsync((string)id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        // GET: Users/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            var user = await _userService.GetByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            var newUser = new EditUserViewModel
            {
                CollegessList = await _context.Collegess.ToListAsync(),

                FullName = user.FullName,
                PhoneNumber = user.PhoneNumber,
                IdentityNumber = user.IdentityNumber,
                IsBlocked = user.IsBlocked,
                DateOfBirth = user.DateOfBirth,
                CollegesId = user.Colleges.Id,
                DepartmentsId = user.Departments.Id,
                SubDepartmentsId = user.SubDepartments.Id,
                RoleId = user.RoleId,
            };
            ViewBag.ViewGover = newUser.CollegessList.ToArray();
            return View(newUser);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, EditUserViewModel user)
        {
            var users = await _userService.GetAllAsync();
            ViewBag.UserCount = users.Count();
            if (ModelState.IsValid)
            {
                try
                {
                    await _userService.UpdateAsync(id, user);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("ViewUsers");
            }
            return View();
        }

        private bool UserExists(string id)
        {
            return string.IsNullOrEmpty(_userService.GetByIdAsync(id).ToString());
        }

        public async Task<IActionResult> ViewCompalintDetails(int id)
        {
            var ComplantList = await _compReop.FindAsync(id);
            AddSolutionVM addsoiationView = new AddSolutionVM()
            {
                UploadsComplainteId = id,
            };
            ComplaintsRejectedVM rejectView = new ComplaintsRejectedVM()
            {
                UploadsComplainteId = id,
            };
            UpComplaintVM upView = new UpComplaintVM()
            {
                UploadsComplainteId = id,
            };
            ProvideSolutionsVM VM = new ProvideSolutionsVM
            {
                compalint = ComplantList,
                Compalints_SolutionList = await _context.Compalints_Solutions.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                ComplaintsRejectedList = await _context.ComplaintsRejecteds.Where(a => a.UploadsComplainteId == id).ToListAsync(),
                RejectedComplaintVM = rejectView,
                UpComplaint = upView,
                AddSolution = addsoiationView
            };
            return View(VM);
        }

        // رفع الشكوى مع سبب الرفع للإدارة العلياء 
        public async Task<IActionResult> UpCompalint(int id, ProvideSolutionsVM model)
        {
            if (ModelState.IsValid)
            {
                var currentUser = await _userManager.GetUserAsync(User);
                var claimsIdentity = (ClaimsIdentity)User.Identity;
                var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                var role = claimsIdentity.FindFirst(ClaimTypes.Role);
                string userRole = role.Value;
                string UserId = claim.Value;
                var subuser = await _context.Users.Where(a => a.Id == UserId).FirstOrDefaultAsync();
                var idComp = model.UpComplaint.UploadsComplainteId;
                var upComplaint = new UpComplaintCause()
                {
                    UserId = subuser.Id,
                    UpProvName = subuser.FullName,
                    UploadsComplainteId = model.UpComplaint.UploadsComplainteId,
                    UpUserProvIdentity = subuser.IdentityNumber,
                    Cause = model.UpComplaint.Cause,
                    DateUp = DateTime.Now,
                    Role = userRole,


                };

                _context.UpComplaintCauses.Add(upComplaint);
                await _context.SaveChangesAsync();


                var upComp = await _compReop.FindAsync(idComp);
                var dbComp = await _context.UploadsComplaintes.FirstOrDefaultAsync(n => n.Id == upComp.Id);
                if (dbComp != null)
                {
                    dbComp.StatusCompalintId = 5;
                    dbComp.StagesComplaintId = upComp.StagesComplaintId + 1;
                    await _context.SaveChangesAsync();
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(AllUpComplaints));



            }
            return NotFound();
        }


        public async Task<IActionResult> RejectedThisComplaint(int id, UploadsComplainte complainte)
        {
            var upComp = await _compReop.FindAsync(id);
            var dbComp = await _context.UploadsComplaintes.FirstOrDefaultAsync(n => n.Id == upComp.Id);
            if (dbComp != null)
            {
                dbComp.Id = complainte.Id;
            
                dbComp.StatusCompalintId = 5;

                await _context.SaveChangesAsync();
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(AllRejectedComplaints));

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectedThisComplaint(ProvideSolutionsVM model, int id)
        {
            if (ModelState.IsValid)
            {
                var currentUser = await _userManager.GetUserAsync(User);
                var claimsIdentity = (ClaimsIdentity)User.Identity;
                var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                var role = claimsIdentity.FindFirst(ClaimTypes.Role);
                string userRole = role.Value;
                string UserId = claim.Value;
                var subuser = await _context.Users.Where(a => a.Id == UserId).FirstOrDefaultAsync();
                var idComp = model.RejectedComplaintVM.UploadsComplainteId;

                var complaintsRejected = new ComplaintsRejected()
                {
                    UserId = subuser.Id,
                    RejectedProvName = subuser.FullName,
                    UploadsComplainteId = model.RejectedComplaintVM.UploadsComplainteId,
                    RejectedUserProvIdentity = subuser.IdentityNumber,
                    reume = model.RejectedComplaintVM.reume,
                    DateSolution = DateTime.Now,
                    Role = userRole,

                };

                _context.ComplaintsRejecteds.Add(complaintsRejected);
                await _context.SaveChangesAsync();

                var upComp = await _compReop.FindAsync(idComp);
                var dbComp = await _context.UploadsComplaintes.FirstOrDefaultAsync(n => n.Id == upComp.Id);
                if (dbComp != null)
                {
                    dbComp.StatusCompalintId = 2;
                    dbComp.StagesComplaintId = 4;
                    await _context.SaveChangesAsync();
                }

                await _context.SaveChangesAsync();
                return RedirectToAction("AllRejectedComplaints");

            }

            return NotFound();

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddSolutions(ProvideSolutionsVM model, int id)
        {
            if (ModelState.IsValid)
            {
                var currentUser = await _userManager.GetUserAsync(User);
                var claimsIdentity = (ClaimsIdentity)User.Identity;
                var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);
                var role = claimsIdentity.FindFirst(ClaimTypes.Role);
                string userRole = role.Value;
                string UserId = claim.Value;
                var subuser = await _context.Users.Where(a => a.Id == UserId).FirstOrDefaultAsync();
                var idComp = model.AddSolution.UploadsComplainteId;
                var solution = new Compalints_Solution()
                {
                    UserId = subuser.Id,
                    SolutionProvName = subuser.FullName,
                    UploadsComplainteId = model.AddSolution.UploadsComplainteId,
                    SolutionProvIdentity = subuser.IdentityNumber,
                    ContentSolution = model.AddSolution.ContentSolution,
                    DateSolution = DateTime.Now,
                    Role = userRole,
                };

                _context.Compalints_Solutions.Add(solution);
                await _context.SaveChangesAsync();

                var upComp = await _compReop.FindAsync(idComp);
                var dbComp = await _context.UploadsComplaintes.FirstOrDefaultAsync(n => n.Id == upComp.Id);
                if (dbComp != null)
                {
                    dbComp.StatusCompalintId = 2;
                    dbComp.StagesComplaintId = 4;
                    await _context.SaveChangesAsync();
                }

                await _context.SaveChangesAsync();
                return RedirectToAction("SolutionComplaints");

            }

            return NotFound();
        }



        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> AddCommunication()
        {

            var currentUser = await GetCurrentUser();
            var communicationDropdownsData = await GetCommunicationDropdownsData(currentUser);
            ViewBag.typeCommun = new SelectList(communicationDropdownsData.TypeCommunications, "Id", "Type");
            ViewBag.UsersName = new SelectList(communicationDropdownsData.ApplicationUsers, "Id", "FullName");

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddCommunication(AddCommunicationVM communication)
        {
            if (ModelState.IsValid)
            {
                var currentUser = await GetCurrentUser();
                var communicationDropdownsData = await GetCommunicationDropdownsData(currentUser);
                ViewBag.typeCommun = new SelectList(communicationDropdownsData.TypeCommunications, "Id", "Type");
                ViewBag.UsersName = new SelectList(communicationDropdownsData.ApplicationUsers, "Id", "Name");

                var currentName = currentUser.FullName;
                var currentPhone = currentUser.PhoneNumber;
                var currentGov = currentUser.CollegesId;
                var currentDir = currentUser.DepartmentsId;
                var currentSub = currentUser.SubDepartmentsId;

                await _compReop.CreateCommuncationAsync(new AddCommunicationVM
                {
                    Titile = communication.Titile,
                    NameUserId = communication.NameUserId,
                    reason = communication.reason,
                    CreateDate = communication.CreateDate,
                    TypeCommuncationId = communication.TypeCommuncationId,
                    UserId = currentUser.Id,
                    BenfName = currentName,
                    BenfPhoneNumber = currentPhone,
                    CollegesId = currentGov,
                    DepartmentsId = currentDir,
                    SubDepartmentsId = currentSub,

                });

                return RedirectToAction("AllCommunication");
            }
            return View(communication);
        }
        private async Task<ApplicationUser> GetCurrentUser()
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var userId = currentUser.Id.ToString();
            var user = await _userManager.FindByIdAsync(userId);
            return user;
        }

        private async Task<SelectDataCommuncationDropdownsVM> GetCommunicationDropdownsData(ApplicationUser currentUser)
        {
            var CollegesId = currentUser.CollegesId;
            var directoryId = currentUser.DepartmentsId;
            var subDirectoryId = currentUser.SubDepartmentsId;
            //var roles = await _userManager.GetRolesAsync(currentUser);

            var roles = await _userManager.GetRolesAsync(currentUser);
            var rolesString = string.Join(",", roles);
            var roleId = _context.Roles.FirstOrDefault(role => role.Name == roles.FirstOrDefault())?.Id;

            return await _compReop.GetAddCommunicationDropdownsValues(subDirectoryId, directoryId, CollegesId, rolesString, roleId);
        }
        public async Task<IActionResult> AllCommunication()
        {
            var currentUser = await GetCurrentUser();
            var communicationDropdownsData = await GetCommunicationDropdownsData(currentUser);

            ViewBag.TypeCommunication = new SelectList(communicationDropdownsData.TypeCommunications, "Id", "Name");

            var result = _context.UsersCommunications.Where(u => u.UserId == currentUser.Id)
            .OrderByDescending(d => d.CreateDate)
            .Include(s => s.User)
            .Include(s => s.TypeCommunication)
            .Include(g => g.Colleges)
            .Include(d => d.Departments)
            .Include(su => su.SubDepartments);

            //List<ApplicationUser> meeting = _context.Users.Where(m => m.Id == ).ToList<ApplicationUser>();

            int totalCompalints = result.Count();

            ViewBag.totalCompalints = totalCompalints;

            return View(result.ToList());
        }
        public async Task<IActionResult> UserReportAsPDF(string Id)
        {
            var comSolution = _context.Compalints_Solutions.Where(u => u.UserId == Id)
                             .GroupBy(c => c.UploadsComplainteId);

            var AcceptSolution = _context.Compalints_Solutions.Where(u => u.UserId == Id)
                             .GroupBy(c => c.UploadsComplainteId, a => a.IsAccept);
            var ComplaintsRejecteds = _context.ComplaintsRejecteds.Where(u => u.UserId == Id)
                             .GroupBy(c => c.UploadsComplainteId);
            var user = await _userService.GetByIdAsync(Id);


            if (user == null)
            {
                return NotFound();
            }

            var result = new UserReportVM
            {
                UserId = user.Id,
                TotlSolutionComp = comSolution.Count(),
                TotlRejectComp = ComplaintsRejecteds.Count(),
                TotlAcceptSolution = AcceptSolution.Count(),
                //Orders = userGroup,
                FullName = user.FullName,
                Gov = user.Colleges.Name,
                Dir = user.Departments.Name,
                Role = user.RoleName,
                PhonNumber = user.PhoneNumber,
                CreatedDate = user.CreatedDate
            };


            return new ViewAsPdf("UserReportAsPDF", result)
            {
                PageOrientation = Orientation.Portrait,
                MinimumFontSize = 25,
                PageSize = Size.A4,
                CustomSwitches = " --print-media-type --no-background --footer-line --header-line --page-offset 0 --footer-center [page] --footer-font-size 8 --footer-right \"page [page] from [topage]\"  "
            };
        }


        public IActionResult AllCirculars()
        {
            return View();
        }



    }
}

