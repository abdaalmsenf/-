﻿namespace CompalintsSystem.Application.Controllers
{
    internal class ComplaintPrintViewModel
    {
        public object ComplaintId { get; set; }
        public object Title { get; set; }
        public object Description { get; set; }
        public object CollegeName { get; set; }
        public object DepartmentName { get; set; }
        public object SubDepartmentName { get; set; }
        public object VillageName { get; set; }
        public object TypeComplaintName { get; set; }
    }
}