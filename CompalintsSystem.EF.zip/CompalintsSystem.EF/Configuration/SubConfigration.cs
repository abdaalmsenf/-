﻿using CompalintsSystem.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CompalintsSystem.EF.Configuration
{
    public class SubConfigration : IEntityTypeConfiguration<SubDepartments>
    {
        public void Configure(EntityTypeBuilder<SubDepartments> builder)
        {
            builder.HasData(
                    new SubDepartments
                    {
                        Id = 1,
                        Name = " الاول",
                        DepartmentsId = 1,
                    },
                      new SubDepartments
                      {
                          Id = 2,
                          Name = " الثاني",
                          DepartmentsId = 1,
                      },
                        new SubDepartments
                        {
                            Id = 3,
                            Name = " الاول",
                            DepartmentsId = 2,
                        },
                        new SubDepartments
                        {
                            Id = 4,
                            Name = " الثاني",
                            DepartmentsId = 2,
                        },
                                                new SubDepartments
                                                {
                                                    Id = 6,
                                                    Name = " الاول",
                                                    DepartmentsId = 3,
                                                },
                        new SubDepartments
                        {
                            Id = 7,
                            Name = " الثاني",
                            DepartmentsId = 3,
                        },
                                                new SubDepartments
                                                {
                                                    Id = 8,
                                                    Name = " الاول",
                                                    DepartmentsId = 4,
                                                },
                        new SubDepartments
                        {
                            Id = 9,
                            Name = " الثاني",
                            DepartmentsId = 4,
                        },
                                                new SubDepartments
                                                {
                                                    Id = 10,
                                                    Name = " الاول",
                                                    DepartmentsId = 5,
                                                },
                        new SubDepartments
                        {
                            Id = 11,
                            Name = " الثاني",
                            DepartmentsId = 5,
                        },
                                                
                        new SubDepartments
                        {
                            Id = 12,
                            Name = " الثاني",
                            DepartmentsId = 6,
                        },
                         new SubDepartments
                         {
                             Id = 5,
                             Name = "الاول",
                             DepartmentsId = 6,
                         }


                );
        }
    }
}
