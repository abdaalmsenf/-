﻿using CompalintsSystem.Core;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace CompalintsSystem.EF.Configuration
{
    public class RoleSeedConfiguration : IEntityTypeConfiguration<IdentityRole>
    {
        public void Configure(EntityTypeBuilder<IdentityRole> builder)
        {
            builder.HasData(
                 new IdentityRole
                 {
                     Id = Guid.NewGuid().ToString(),
                     Name = UserRoles.AdminGeneralFederation,
                     NormalizedName = UserRoles.AdminGeneralFederation.ToUpper(),

                 },
                 new IdentityRole
                 {
                     Id = Guid.NewGuid().ToString(),
                     Name = UserRoles.AdminColleges,
                     NormalizedName = UserRoles.AdminColleges.ToUpper(),

                 }
                 ,
                 new IdentityRole
                 {
                     Id = Guid.NewGuid().ToString(),
                     Name = UserRoles.AdminDepartments,
                     NormalizedName = UserRoles.AdminDepartments.ToUpper(),


                 },
                 new IdentityRole
                 {
                     Id = Guid.NewGuid().ToString(),
                     Name = UserRoles.AdminSubDepartments,
                     NormalizedName = UserRoles.AdminSubDepartments.ToUpper(),

                 },

                  new IdentityRole
                  {
                      Id = Guid.NewGuid().ToString(),
                      Name = UserRoles.Beneficiarie,
                      NormalizedName = UserRoles.Beneficiarie.ToUpper(),

                  }

            );
        }
    }
}