﻿using CompalintsSystem.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CompalintsSystem.EF.Configuration
{
    public class DirConfigration : IEntityTypeConfiguration<Departments>
    {


        public void Configure(EntityTypeBuilder<Departments> builder)
        {
            builder.HasData(
                    new Departments
                    {
                        Id = 1,
                        Name = "الطب البشري",
                        CollegesId = 1,
                    },
                    new Departments
                    {
                        Id = 2,
                        Name = "علوم حاسوب",
                        CollegesId = 2,

                    },
                     new Departments
                     {
                         Id = 5,
                         Name = "هندسة مدني",
                         CollegesId = 2,

                     },
                     new Departments
                     {
                         Id = 3,
                         Name = "صيدلة",
                         CollegesId = 1,

                     },
                      new Departments
                      {
                          Id = 6,
                          Name = "فيزياء",
                          CollegesId = 3,

                      },
                      new Departments
                      {
                          Id = 4,
                          Name = "قران",
                          CollegesId = 3,

                      }
                );
        }




    }
}
