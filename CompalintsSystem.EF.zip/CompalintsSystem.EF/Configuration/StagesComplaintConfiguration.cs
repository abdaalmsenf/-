﻿using CompalintsSystem.Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CompalintsSystem.EF.Configuration
{
    public class StagesComplaintConfiguration : IEntityTypeConfiguration<StagesComplaint>
    {
        public void Configure(EntityTypeBuilder<StagesComplaint> builder)
        {
            builder.HasData(

                    new StagesComplaint
                    {
                        Id = 1,
                        Name = "المستوى",
                    },
                     new StagesComplaint
                     {
                         Id = 2,
                         Name = "القسم",
                     },
                      new StagesComplaint
                      {
                          Id = 3,
                          Name = "الكلية",
                      },
                       new StagesComplaint
                       {
                           Id = 4,
                           Name = "الادارة العامة",
                       }
                );
        }


    }

}